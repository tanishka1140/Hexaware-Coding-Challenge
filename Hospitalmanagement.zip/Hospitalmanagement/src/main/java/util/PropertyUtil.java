package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyUtil {

    public static String getPropertyString(String filePath) throws IOException {
        Properties props = new Properties();
        props.load(new FileInputStream(filePath));

        String url = props.getProperty("url");
        String user = props.getProperty("user");
        String password = props.getProperty("password");

        return url + "?user=" + user + "&password=" + password;
    }
}
