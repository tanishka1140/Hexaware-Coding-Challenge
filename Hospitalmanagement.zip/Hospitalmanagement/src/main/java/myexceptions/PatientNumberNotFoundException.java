package myexceptions ;

public class PatientNumberNotFoundException extends Exception {

    public PatientNumberNotFoundException() {
        super("Patient number not found in database.");
    }

    public PatientNumberNotFoundException(String message) {
        super(message);
    }
}
