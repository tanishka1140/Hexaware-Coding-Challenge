package main;

import dao.HospitalServiceImpl;
import dao.IHospitalService;
import entity.Appointment;
import myexceptions.PatientNumberNotFoundException;

import java.util.List;
import java.util.Scanner;

public class MainModule {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        IHospitalService service = new HospitalServiceImpl();
        boolean exit = false;

        while (!exit) {
            System.out.println("\n===== Hospital Management System =====");
            System.out.println("1. Schedule Appointment");
            System.out.println("2. Get Appointment by ID");
            System.out.println("3. Get Appointments for Patient");
            System.out.println("4. Get Appointments for Doctor");
            System.out.println("5. Update Appointment");
            System.out.println("6. Cancel Appointment");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = Integer.parseInt(scanner.nextLine());

            try {
                switch (choice) {
                    case 1:
                        Appointment newAppointment = readAppointmentInput(scanner);
                        boolean scheduled = service.scheduleAppointment(newAppointment);
                        System.out.println(scheduled ? "Appointment Scheduled!" : "Failed to schedule.");
                        break;

                    case 2:
                        System.out.print("Enter Appointment ID: ");
                        int appId = Integer.parseInt(scanner.nextLine());
                        Appointment found = service.getAppointmentById(appId);
                        System.out.println(found != null ? found : "No Appointment Found");
                        break;

                    case 3:
                        System.out.print("Enter Patient ID: ");
                        int patientId = Integer.parseInt(scanner.nextLine());
                        List<Appointment> patientAppointments = service.getAppointmentsForPatient(patientId);
                        if (patientAppointments.isEmpty()) {
                            throw new PatientNumberNotFoundException("Patient ID not found or no appointments.");
                        }
                        patientAppointments.forEach(System.out::println);
                        break;

                    case 4:
                        System.out.print("Enter Doctor ID: ");
                        int doctorId = Integer.parseInt(scanner.nextLine());
                        List<Appointment> doctorAppointments = service.getAppointmentsForDoctor(doctorId);
                        if (doctorAppointments.isEmpty()) {
                            System.out.println("No appointments found for this doctor.");
                        } else {
                            doctorAppointments.forEach(System.out::println);
                        }
                        break;

                    case 5:
                        Appointment updatedAppointment = readAppointmentInput(scanner);
                        boolean updated = service.updateAppointment(updatedAppointment);
                        System.out.println(updated ? "Appointment Updated!" : "Update Failed.");
                        break;

                    case 6:
                        System.out.print("Enter Appointment ID to cancel: ");
                        int cancelId = Integer.parseInt(scanner.nextLine());
                        boolean cancelled = service.cancelAppointment(cancelId);
                        System.out.println(cancelled ? "Appointment Cancelled!" : "Cancellation Failed.");
                        break;

                    case 7:
                        exit = true;
                        System.out.println("Exiting System. Goodbye!");
                        break;

                    default:
                        System.out.println("Invalid choice! Please try again.");
                        break;
                }
            } catch (PatientNumberNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected Error: " + e.getMessage());
            }
        }
        scanner.close();
    }

    private static Appointment readAppointmentInput(Scanner scanner) {
        System.out.print("Enter Appointment ID (0 if new): ");
        int appointmentId = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter Patient ID: ");
        int patientId = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter Doctor ID: ");
        int doctorId = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
        String date = scanner.nextLine();

        System.out.print("Enter Description: ");
        String desc = scanner.nextLine();

        return new Appointment(appointmentId, patientId, doctorId, date, desc);
    }
}
