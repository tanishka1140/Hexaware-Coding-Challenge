package dao;

import entity.Appointment;
import util.DBConnection;
import myexceptions.PatientNumberNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HospitalServiceImpl implements IHospitalService {

    private Connection conn = DBConnection.getConnection();

    @Override
    public Appointment getAppointmentById(int appointmentId) {
        Appointment appointment = null;
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Appointment WHERE appointmentId = ?");
            stmt.setInt(1, appointmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                appointment = new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getString("appointmentDate"),
                        rs.getString("description")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error fetching appointment: " + e.getMessage());
        }
        return appointment;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId) {
        List<Appointment> appointments = new ArrayList<>();
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Appointment WHERE patientId = ?");
            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                appointments.add(new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getString("appointmentDate"),
                        rs.getString("description")
                ));
            }
            if (appointments.isEmpty()) {
                throw new PatientNumberNotFoundException("No appointments found for Patient ID: " + patientId);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching appointments: " + e.getMessage());
        } catch (PatientNumberNotFoundException e) {
            System.out.println(e.getMessage());
        }
        return appointments;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
        List<Appointment> appointments = new ArrayList<>();
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Appointment WHERE doctorId = ?");
            stmt.setInt(1, doctorId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                appointments.add(new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getString("appointmentDate"),
                        rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching appointments: " + e.getMessage());
        }
        return appointments;
    }

    @Override
    public boolean scheduleAppointment(Appointment appointment) {
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO Appointment (appointmentId, patientId, doctorId, appointmentDate, description) VALUES (?, ?, ?, ?, ?)");
            stmt.setInt(1, appointment.getAppointmentId());
            stmt.setInt(2, appointment.getPatientId());
            stmt.setInt(3, appointment.getDoctorId());
            stmt.setString(4, appointment.getAppointmentDate());
            stmt.setString(5, appointment.getDescription());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("Error scheduling appointment: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean updateAppointment(Appointment appointment) {
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE Appointment SET patientId=?, doctorId=?, appointmentDate=?, description=? WHERE appointmentId=?");
            stmt.setInt(1, appointment.getPatientId());
            stmt.setInt(2, appointment.getDoctorId());
            stmt.setString(3, appointment.getAppointmentDate());
            stmt.setString(4, appointment.getDescription());
            stmt.setInt(5, appointment.getAppointmentId());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("Error updating appointment: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean cancelAppointment(int appointmentId) {
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Appointment WHERE appointmentId = ?");
            stmt.setInt(1, appointmentId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("Error cancelling appointment: " + e.getMessage());
            return false;
        }
    }
}
