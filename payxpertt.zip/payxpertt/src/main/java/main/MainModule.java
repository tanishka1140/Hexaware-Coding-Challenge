package main;

import service.*;
import entity.Employee;
import entity.Payroll;
import entity.Tax;
import entity.FinancialRecord;
import exception.*;

import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        IEmployeeService employeeService = new EmployeeServiceImpl();
        IPayrollService payrollService = new PayrollServiceImpl();
        ITaxService taxService = new TaxServiceImpl();
        IFinancialRecordService financialService = new FinancialRecordServiceImpl();

        while (true) {
            System.out.println("\n=== PayXpert Payroll System ===");
            System.out.println("1. Add Employee");
            System.out.println("2. Get Employee by ID");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Generate Payroll");
            System.out.println("6. Calculate Tax");
            System.out.println("7. Get Tax by ID");
            System.out.println("8. Get Taxes for Employee");
            System.out.println("9. Get Taxes for Year");
            System.out.println("10. Add Financial Record");
            System.out.println("11. Get Financial Record by ID");
            System.out.println("12. Get Financial Records for Employee");
            System.out.println("13. Get Financial Records for Date");
            System.out.println("14. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear buffer

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter First Name: ");
                        String firstName = scanner.nextLine();
                        System.out.print("Enter Last Name: ");
                        String lastName = scanner.nextLine();
                        System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
                        String dob = scanner.nextLine();
                        System.out.print("Enter Gender (M/F): ");
                        String gender = scanner.nextLine();
                        System.out.print("Enter Email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter Phone Number: ");
                        String phone = scanner.nextLine();
                        System.out.print("Enter Address: ");
                        String address = scanner.nextLine();
                        System.out.print("Enter Position: ");
                        String position = scanner.nextLine();
                        System.out.print("Enter Joining Date (YYYY-MM-DD): ");
                        String joinDate = scanner.nextLine();
                        System.out.print("Enter Termination Date (YYYY-MM-DD or leave blank): ");
                        String termDate = scanner.nextLine();
                        String termination = termDate.isEmpty() ? null : termDate;
                        Employee emp = new Employee(0, firstName, lastName, dob, gender, email, phone, address, position, joinDate, termination);
                        employeeService.addEmployee(emp);
                        System.out.println("Employee added successfully!");
                        break;

                    case 2:
                        System.out.print("Enter Employee ID: ");
                        int empId = scanner.nextInt();
                        Employee employee = employeeService.getEmployeeById(empId);
                        System.out.println(employee);
                        break;

                    case 3:
                        System.out.print("Enter Employee ID to Update: ");
                        int updateId = scanner.nextInt();
                        scanner.nextLine();
                        Employee existingEmp = employeeService.getEmployeeById(updateId);
                        System.out.print("Enter New First Name (or Enter to keep '" + existingEmp.getFirstName() + "'): ");
                        String newFirstName = scanner.nextLine();
                        firstName = newFirstName.isEmpty() ? existingEmp.getFirstName() : newFirstName;
                        System.out.print("Enter New Last Name (or Enter to keep '" + existingEmp.getLastName() + "'): ");
                        String newLastName = scanner.nextLine();
                        lastName = newLastName.isEmpty() ? existingEmp.getLastName() : newLastName;
                        System.out.print("Enter New Date of Birth (or Enter to keep '" + existingEmp.getDateOfBirth() + "'): ");
                        String newDob = scanner.nextLine();
                        dob = newDob.isEmpty() ? existingEmp.getDateOfBirth() : newDob;
                        System.out.print("Enter New Gender (or Enter to keep '" + existingEmp.getGender() + "'): ");
                        String newGender = scanner.nextLine();
                        gender = newGender.isEmpty() ? existingEmp.getGender() : newGender;
                        System.out.print("Enter New Email (or Enter to keep '" + existingEmp.getEmail() + "'): ");
                        String newEmail = scanner.nextLine();
                        email = newEmail.isEmpty() ? existingEmp.getEmail() : newEmail;
                        System.out.print("Enter New Phone Number (or Enter to keep '" + existingEmp.getPhoneNumber() + "'): ");
                        String newPhone = scanner.nextLine();
                        phone = newPhone.isEmpty() ? existingEmp.getPhoneNumber() : newPhone;
                        System.out.print("Enter New Address (or Enter to keep '" + existingEmp.getAddress() + "'): ");
                        String newAddress = scanner.nextLine();
                        address = newAddress.isEmpty() ? existingEmp.getAddress() : newAddress;
                        System.out.print("Enter New Position (or Enter to keep '" + existingEmp.getPosition() + "'): ");
                        String newPosition = scanner.nextLine();
                        position = newPosition.isEmpty() ? existingEmp.getPosition() : newPosition;
                        System.out.print("Enter New Joining Date (or Enter to keep '" + existingEmp.getJoiningDate() + "'): ");
                        String newJoinDate = scanner.nextLine();
                        joinDate = newJoinDate.isEmpty() ? existingEmp.getJoiningDate() : newJoinDate;
                        System.out.print("Enter New Termination Date (or Enter to keep '" + (existingEmp.getTerminationDate() != null ? existingEmp.getTerminationDate() : "none") + "'): ");
                        String newTerm = scanner.nextLine();
                        termination = newTerm.isEmpty() ? existingEmp.getTerminationDate() : newTerm;
                        Employee updatedEmp = new Employee(updateId, firstName, lastName, dob, gender, email, phone, address, position, joinDate, termination);
                        employeeService.updateEmployee(updatedEmp);
                        System.out.println("Employee updated successfully!");
                        break;

                    case 4:
                        System.out.print("Enter Employee ID to Delete: ");
                        int deleteId = scanner.nextInt();
                        employeeService.deleteEmployee(deleteId);
                        System.out.println("Employee deleted successfully!");
                        break;

                    case 5:
                        System.out.print("Enter Employee ID: ");
                        int payrollEmpId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Pay Period Start Date (YYYY-MM-DD): ");
                        String start = scanner.nextLine();
                        System.out.print("Enter Pay Period End Date (YYYY-MM-DD): ");
                        String end = scanner.nextLine();
                        System.out.print("Enter Basic Salary: ");
                        double basic = scanner.nextDouble();
                        System.out.print("Enter Overtime Pay: ");
                        double overtime = scanner.nextDouble();
                        System.out.print("Enter Deductions: ");
                        double deductions = scanner.nextDouble();
                        double net = basic + overtime - deductions;
                        Payroll payroll = new Payroll(0, payrollEmpId, start, end, basic, overtime, deductions, net);
                        payrollService.generatePayroll(payroll);
                        System.out.println("Payroll generated successfully! Net Salary: " + net);
                        break;

                    case 6:
                        System.out.print("Enter Employee ID: ");
                        int taxEmpId = scanner.nextInt();
                        System.out.print("Enter Tax Year: ");
                        int taxYear = scanner.nextInt();
                        double tax = taxService.calculateTax(taxEmpId, taxYear);
                        System.out.println("Tax Amount: " + tax);
                        break;

                    case 7:
                        System.out.print("Enter Tax ID: ");
                        int taxId = scanner.nextInt();
                        Tax taxById = taxService.getTaxById(taxId);
                        System.out.println(taxById);
                        break;

                    case 8:
                        System.out.print("Enter Employee ID: ");
                        int empIdForTaxes = scanner.nextInt();
                        List<Tax> taxesForEmp = taxService.getTaxesForEmployee(empIdForTaxes);
                        System.out.println("Taxes for Employee ID " + empIdForTaxes + ": " + taxesForEmp);
                        break;

                    case 9:
                        System.out.print("Enter Tax Year: ");
                        int yearForTaxes = scanner.nextInt();
                        List<Tax> taxesForYear = taxService.getTaxesForYear(yearForTaxes);
                        System.out.println("Taxes for Year " + yearForTaxes + ": " + taxesForYear);
                        break;

                    case 10:
                        System.out.print("Enter Employee ID: ");
                        int recordEmpId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Description: ");
                        String desc = scanner.nextLine();
                        System.out.print("Enter Amount: ");
                        double amount = scanner.nextDouble();
                        scanner.nextLine();
                        System.out.print("Enter Record Type: ");
                        String type = scanner.nextLine();
                        System.out.print("Enter Record Date (YYYY-MM-DD): ");
                        String date = scanner.nextLine();
                        financialService.addFinancialRecord(recordEmpId, desc, amount, type, date);
                        System.out.println("Financial record added successfully!");
                        break;

                    case 11:
                        System.out.print("Enter Record ID: ");
                        int recordId = scanner.nextInt();
                        FinancialRecord record = financialService.getFinancialRecordById(recordId);
                        System.out.println(record);
                        break;

                    case 12:
                        System.out.print("Enter Employee ID: ");
                        int empIdForRecords = scanner.nextInt();
                        List<FinancialRecord> recordsForEmp = financialService.getFinancialRecordsForEmployee(empIdForRecords);
                        System.out.println("Records for Employee ID " + empIdForRecords + ": " + recordsForEmp);
                        break;

                    case 13:
                        System.out.print("Enter Record Date (YYYY-MM-DD): ");
                        scanner.nextLine(); // Clear buffer
                        String recordDate = scanner.nextLine();
                        List<FinancialRecord> recordsForDate = financialService.getFinancialRecordsForDate(recordDate);
                        System.out.println("Records for Date " + recordDate + ": " + recordsForDate);
                        break;

                    case 14:
                        System.out.println("Exiting...");
                        scanner.close();
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice!");
                }
            } catch (EmployeeNotFoundException | PayrollGenerationException | TaxCalculationException |
                     FinancialRecordException | InvalidInputException | DatabaseConnectionException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }
}