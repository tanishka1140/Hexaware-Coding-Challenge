package dao;

import entity.FinancialRecord;
import exception.FinancialRecordException;

import java.util.List;

public interface IFinancialRecordDao {
    void addFinancialRecord(int employeeId, String description, double amount, String recordType, String recordDate) throws FinancialRecordException;
    FinancialRecord getFinancialRecordById(int recordId) throws FinancialRecordException;
    List<FinancialRecord> getFinancialRecordsForEmployee(int employeeId) throws FinancialRecordException;
    List<FinancialRecord> getFinancialRecordsForDate(String recordDate) throws FinancialRecordException;
}