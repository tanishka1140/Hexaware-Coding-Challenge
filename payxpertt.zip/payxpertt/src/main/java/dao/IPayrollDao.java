package dao;

import entity.Payroll;
import exception.PayrollGenerationException;

public interface IPayrollDao {
    void generatePayroll(Payroll payroll) throws PayrollGenerationException;
}