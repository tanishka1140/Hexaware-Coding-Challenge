package dao;

import entity.FinancialRecord;
import exception.FinancialRecordException;
import util.DBConnUtil;
import util.DBPropertyUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FinancialRecordDaoImpl implements IFinancialRecordDao {
    private static final String CONN_STRING = DBPropertyUtil.getConnectionString("src/main/resources/db.properties");

    @Override
    public void addFinancialRecord(int employeeId, String description, double amount, String recordType, String recordDate) throws FinancialRecordException {
        String query = "INSERT INTO FinancialRecord (EmployeeID, RecordDate, Description, Amount, RecordType) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            stmt.setString(2, recordDate);
            stmt.setString(3, description);
            stmt.setDouble(4, amount);
            stmt.setString(5, recordType);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new FinancialRecordException("Error adding financial record: " + e.getMessage());
        }
    }

    @Override
    public FinancialRecord getFinancialRecordById(int recordId) throws FinancialRecordException {
        String query = "SELECT * FROM FinancialRecord WHERE RecordID = ?";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, recordId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new FinancialRecord(
                        rs.getInt("RecordID"),
                        rs.getInt("EmployeeID"),
                        rs.getString("RecordDate"),
                        rs.getString("Description"),
                        rs.getDouble("Amount"),
                        rs.getString("RecordType")
                );
            } else {
                throw new FinancialRecordException("Financial record with ID " + recordId + " not found");
            }
        } catch (SQLException e) {
            throw new FinancialRecordException("Error fetching financial record: " + e.getMessage());
        }
    }

    @Override
    public List<FinancialRecord> getFinancialRecordsForEmployee(int employeeId) throws FinancialRecordException {
        String query = "SELECT * FROM FinancialRecord WHERE EmployeeID = ?";
        List<FinancialRecord> records = new ArrayList<>();
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                records.add(new FinancialRecord(
                        rs.getInt("RecordID"),
                        rs.getInt("EmployeeID"),
                        rs.getString("RecordDate"),
                        rs.getString("Description"),
                        rs.getDouble("Amount"),
                        rs.getString("RecordType")
                ));
            }
            return records;
        } catch (SQLException e) {
            throw new FinancialRecordException("Error fetching financial records for employee: " + e.getMessage());
        }
    }

    @Override
    public List<FinancialRecord> getFinancialRecordsForDate(String recordDate) throws FinancialRecordException {
        String query = "SELECT * FROM FinancialRecord WHERE RecordDate = ?";
        List<FinancialRecord> records = new ArrayList<>();
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, recordDate);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                records.add(new FinancialRecord(
                        rs.getInt("RecordID"),
                        rs.getInt("EmployeeID"),
                        rs.getString("RecordDate"),
                        rs.getString("Description"),
                        rs.getDouble("Amount"),
                        rs.getString("RecordType")
                ));
            }
            return records;
        } catch (SQLException e) {
            throw new FinancialRecordException("Error fetching financial records for date: " + e.getMessage());
        }
    }
}