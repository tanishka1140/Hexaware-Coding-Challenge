package dao;

import entity.Tax;
import exception.TaxCalculationException;
import util.DBConnUtil;
import util.DBPropertyUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TaxDaoImpl implements ITaxDao {
    private static final String CONN_STRING = DBPropertyUtil.getConnectionString("src/main/resources/db.properties");

    @Override
    public double calculateTax(int employeeId, int taxYear) throws TaxCalculationException {
        String query = "SELECT SUM(BasicSalary + OvertimePay) as annualIncome FROM Payroll WHERE EmployeeID = ? AND YEAR(PayPeriodStartDate) = ?";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            stmt.setInt(2, taxYear);
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getDouble("annualIncome") > 0) {
                double taxableIncome = rs.getDouble("annualIncome");
                double taxAmount = taxableIncome * 0.2; // 20% tax rate
                String insertQuery = "INSERT INTO Tax (EmployeeID, TaxYear, TaxableIncome, TaxAmount) VALUES (?, ?, ?, ?)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
                    insertStmt.setInt(1, employeeId);
                    insertStmt.setInt(2, taxYear);
                    insertStmt.setDouble(3, taxableIncome);
                    insertStmt.setDouble(4, taxAmount);
                    insertStmt.executeUpdate();
                }
                return taxAmount;
            } else {
                throw new TaxCalculationException("No payroll data found for employee " + employeeId + " in " + taxYear);
            }
        } catch (SQLException e) {
            throw new TaxCalculationException("Error calculating tax: " + e.getMessage());
        }
    }

    @Override
    public Tax getTaxById(int taxId) throws TaxCalculationException {
        String query = "SELECT * FROM Tax WHERE TaxID = ?";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, taxId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Tax(
                        rs.getInt("TaxID"),
                        rs.getInt("EmployeeID"),
                        rs.getInt("TaxYear"),
                        rs.getDouble("TaxableIncome"),
                        rs.getDouble("TaxAmount")
                );
            } else {
                throw new TaxCalculationException("Tax with ID " + taxId + " not found");
            }
        } catch (SQLException e) {
            throw new TaxCalculationException("Error fetching tax: " + e.getMessage());
        }
    }

    @Override
    public List<Tax> getTaxesForEmployee(int employeeId) throws TaxCalculationException {
        String query = "SELECT * FROM Tax WHERE EmployeeID = ?";
        List<Tax> taxes = new ArrayList<>();
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                taxes.add(new Tax(
                        rs.getInt("TaxID"),
                        rs.getInt("EmployeeID"),
                        rs.getInt("TaxYear"),
                        rs.getDouble("TaxableIncome"),
                        rs.getDouble("TaxAmount")
                ));
            }
            return taxes;
        } catch (SQLException e) {
            throw new TaxCalculationException("Error fetching taxes for employee: " + e.getMessage());
        }
    }

    @Override
    public List<Tax> getTaxesForYear(int taxYear) throws TaxCalculationException {
        String query = "SELECT * FROM Tax WHERE TaxYear = ?";
        List<Tax> taxes = new ArrayList<>();
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, taxYear);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                taxes.add(new Tax(
                        rs.getInt("TaxID"),
                        rs.getInt("EmployeeID"),
                        rs.getInt("TaxYear"),
                        rs.getDouble("TaxableIncome"),
                        rs.getDouble("TaxAmount")
                ));
            }
            return taxes;
        } catch (SQLException e) {
            throw new TaxCalculationException("Error fetching taxes for year: " + e.getMessage());
        }
    }
}