package service;

import entity.Payroll;
import exception.PayrollGenerationException;

public interface IPayrollService {
    void generatePayroll(Payroll payroll) throws PayrollGenerationException;
}