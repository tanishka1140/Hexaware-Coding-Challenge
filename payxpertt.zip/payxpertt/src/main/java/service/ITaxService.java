package service;

import entity.Tax;
import exception.TaxCalculationException;

import java.util.List;

public interface ITaxService {
    double calculateTax(int employeeId, int taxYear) throws TaxCalculationException;
    Tax getTaxById(int taxId) throws TaxCalculationException;
    List<Tax> getTaxesForEmployee(int employeeId) throws TaxCalculationException;
    List<Tax> getTaxesForYear(int taxYear) throws TaxCalculationException;
}