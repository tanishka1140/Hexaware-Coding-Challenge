CREATE DATABASE PayXpert;
USE PayXpert;

show tables;
-- Employee Table
CREATE TABLE Employee (
    EmployeeID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Gender CHAR(1),
    Email VARCHAR(100) UNIQUE,
    PhoneNumber VARCHAR(15),
    Address VARCHAR(255),
    Position VARCHAR(50),
    JoiningDate DATE NOT NULL,
    TerminationDate DATE
);

-- Payroll Table
CREATE TABLE Payroll (
    PayrollID INT PRIMARY KEY AUTO_INCREMENT,
    EmployeeID INT,
    PayPeriodStartDate DATE NOT NULL,
    PayPeriodEndDate DATE NOT NULL,
    BasicSalary DECIMAL(10, 2) NOT NULL,
    OvertimePay DECIMAL(10, 2) DEFAULT 0.00,
    Deductions DECIMAL(10, 2) DEFAULT 0.00,
    NetSalary DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);

-- Tax Table
CREATE TABLE Tax (
    TaxID INT PRIMARY KEY AUTO_INCREMENT,
    EmployeeID INT,
    TaxYear INT NOT NULL,
    TaxableIncome DECIMAL(10, 2) NOT NULL,
    TaxAmount DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);

-- FinancialRecord Table
CREATE TABLE FinancialRecord (
    RecordID INT PRIMARY KEY AUTO_INCREMENT,
    EmployeeID INT,
    RecordDate DATE NOT NULL,
    Description VARCHAR(100),
    Amount DECIMAL(10, 2) NOT NULL,
    RecordType VARCHAR(50),
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);


INSERT INTO Employee (FirstName, LastName, DateOfBirth, Gender, Email, PhoneNumber, Address, Position, JoiningDate, TerminationDate) VALUES
('John', 'Doe', '1990-05-15', 'M', 'john.doe@example.com', '123-456-7890', '123 Elm St, Springfield', 'Software Engineer', '2020-01-10', NULL),
('Jane', 'Smith', '1985-08-22', 'F', 'jane.smith@example.com', '234-567-8901', '456 Oak St, Springfield', 'HR Manager', '2019-03-15', NULL),
('Michael', 'Brown', '1992-11-30', 'M', 'michael.brown@example.com', '345-678-9012', '789 Pine St, Springfield', 'Accountant', '2021-06-01', NULL),
('Emily', 'Davis', '1988-02-14', 'F', 'emily.davis@example.com', '456-789-0123', '101 Maple St, Springfield', 'Marketing Lead', '2018-09-20', '2023-12-31'),
('Robert', 'Wilson', '1995-07-09', 'M', 'robert.wilson@example.com', '567-890-1234', '202 Birch St, Springfield', 'Sales Representative', '2022-02-15', NULL);

INSERT INTO Payroll (EmployeeID, PayPeriodStartDate, PayPeriodEndDate, BasicSalary, OvertimePay, Deductions, NetSalary) VALUES
(1, '2025-03-01', '2025-03-15', 3000.00, 200.00, 300.00, 2900.00),
(2, '2025-03-01', '2025-03-15', 4000.00, 0.00, 400.00, 3600.00),
(3, '2025-03-01', '2025-03-15', 3500.00, 150.00, 350.00, 3300.00),
(4, '2025-03-01', '2025-03-15', 3200.00, 0.00, 320.00, 2880.00),
(5, '2025-03-01', '2025-03-15', 2800.00, 100.00, 280.00, 2620.00);

INSERT INTO Tax (EmployeeID, TaxYear, TaxableIncome, TaxAmount) VALUES
(1, 2025, 36000.00, 7200.00), -- Assuming 20% tax rate
(2, 2025, 48000.00, 9600.00),
(3, 2025, 42000.00, 8400.00),
(4, 2025, 38400.00, 7680.00),
(5, 2025, 33600.00, 6720.00);

INSERT INTO FinancialRecord (EmployeeID, RecordDate, Description, Amount, RecordType) VALUES
(1, '2025-03-15', 'March Salary Payment', 2900.00, 'Income'),
(2, '2025-03-15', 'Bonus Payment', 500.00, 'Income'),
(3, '2025-03-10', 'Tax Deduction', -8400.00, 'Tax Payment'),
(4, '2025-03-05', 'Travel Reimbursement', 200.00, 'Income'),
(5, '2025-03-15', 'Health Insurance Deduction', -150.00, 'Expense');

SELECT * FROM Employee;
SELECT * FROM Payroll;
SELECT * FROM Tax;
SELECT * FROM FinancialRecord;